git pull
python auto_spy_bot.py